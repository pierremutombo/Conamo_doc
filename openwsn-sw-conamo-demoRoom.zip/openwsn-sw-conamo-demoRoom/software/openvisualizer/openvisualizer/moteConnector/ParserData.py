# Copyright (c) 2010-2013, Regents of the University of California. 
# All rights reserved. 
#  
# Released under the BSD 3-Clause license as published at the link below.
# https://openwsn.atlassian.net/wiki/display/OW/License
import logging
log = logging.getLogger('ParserData')
log.setLevel(logging.ERROR)
log.addHandler(logging.NullHandler())

CONAMOLogger = logging.getLogger('CONAMO')

import struct
import json

from pydispatch import dispatcher

from argparse       import ArgumentParser

from ParserException import ParserException
import Parser
import time
import openVisualizerWeb

import sys
sys.path.append('/home/emunicio/EclipseProjects/OpenWSN-conamo-dev/openVisualizer-Conamo/openwsn-sw-conamo/software/websocketserver')
from SingletonWS import SingletonWS


class ParserData(Parser.Parser):
    
    HEADER_LENGTH  = 2
    MSPERSLOT      = 15 #ms per slot.
    
    IPHC_SAM       = 4
    IPHC_DAM       = 0
    
    UINJECT_MASK    = 'uinject'
     
    def __init__(self):
        
        # log
        log.info("create instance")
        
        # initialize parent class
        Parser.Parser.__init__(self,self.HEADER_LENGTH)

        self.parser = ArgumentParser()
        self.argspace = self.parser.parse_known_args()[0]
        
        self._asn= ['asn_4',                     # B
          'asn_2_3',                   # H
          'asn_0_1',                   # H
         ]
    
    
    #======================== public ==========================================
    
    def parseInput(self,input):
	#print "rec "+str(input[-7:])
	if input[7] == 88:

		CONAMOLogger.info(input)


		#print input


#		#No ASNs per hop


#		val=input[40]

#		if (val & (1 << (8 - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
#            		val = val - (1 << 8)        # compute negative value
#       
#		rssi1=val

#		val=input[43]

#		if (val & (1 << (8 - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
#            		val = val - (1 << 8)        # compute negative value
#		rssi2=val

#		val=input[46]

#		if (val & (1 << (8 - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
#            		val = val - (1 << 8)        # compute negative value
#		rssi3=val

#		val=input[49]

#		if (val & (1 << (8 - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
#            		val = val - (1 << 8)        # compute negative value
#		rssi4=val

#		
#		a=str((input[9],input[10]))+" C "+str(input[-10])+" N "+str((input[11]*256)+input[12])+" - "+str(time.time())+" hrm "+str(input[22])+" "+str(time.strftime('%l:%M%p'))+" P0:"+str(input[38])+","+str(input[39])+" RSSI "+str(rssi1)+" P1:"+str(input[41])+","+str(input[42])+" RSSI "+str(rssi2)+" P2:"+str(input[44])+","+str(input[45])+" RSSI "+str(rssi3)+" P3:"+str(input[47])+","+str(input[48])+" RSSI "+str(rssi4)+" RANK "+str(input[-2]*256+input[-1])
		
		#With ASNs per hop


		val=input[40]

		if (val & (1 << (8 - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
            		val = val - (1 << 8)        # compute negative value
       
		rssi1=val

		val=input[46]

		if (val & (1 << (8 - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
            		val = val - (1 << 8)        # compute negative value
		rssi2=val

		val=input[52]

		if (val & (1 << (8 - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
            		val = val - (1 << 8)        # compute negative value
		rssi3=val

#		val=input[58]

#		if (val & (1 << (8 - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
#            		val = val - (1 << 8)        # compute negative value
#		rssi4=val

		a=str((input[9],input[10]))+" C "+str(input[-3])+" N "+str((input[11]*256)+input[12])+" - "+str(time.time())+" HRM "+str(input[22])+" "+str(time.strftime('%l:%M%p'))+" P0:"+str(input[38])+","+str(input[39])+" RSSI "+str(rssi1)+" AsnLat "+str(input[41])+","+str(input[42])+","+str(input[43])+" P1:"+str(input[44])+","+str(input[45])+" RSSI "+str(rssi2)+" AsnLat "+str(input[47])+","+str(input[48])+","+str(input[49])+" P2:"+str(input[50])+","+str(input[51])+" RSSI "+str(rssi3)+" RANK "+str(input[-2]*256+input[-1])

                dData = {}
                dData['deviceUUID'] = input[9] * 16**2 + input[10]
                # HEARTRATE SENSOR UUID
		dData['sensorUUID'] = input[20] * 16**2 + input[21]

                dData['timestamp'] = time.time()
                dData['counter'] = input[11] * 16**2 + input[12]

		# SPEED
                dData['speed'] = input[34] * 16**2 + input[35]
		# HRM
                dData['heartrate'] = input[22]
		# LOCATION
                dData['location'] = {}
		dData['location']['lon'] = input[28] * 16**6 + input[29] * 16**4 + input[30] * 16**2 + input[31]
		dData['location']['lat'] = input[24] * 16**6 + input[25] * 16**4 + input[26] * 16**2 + input[27]
		dData['location']['nsew'] = input[23]
                CONAMOLogger.info(dData)

                # send LOCATION
                if SingletonWS.getInstance().isEnabled():
                    jsonData = json.dumps(dData)
                    SingletonWS.getInstance().broadcastToClients(dData)

		filehrm = open("filehrm", "w")
		filecad = open("filecad", "w")
		filespd = open("filespd", "w")
		filepwr = open("filepwr", "w")

#		fil.write(a+" Lat "+str(dData['location']['lat'])+" Lon "+str(dData['location']['lon'])+"\n") 
#		#fil.write("AAA> "+str(input)+"\n")
#		#file.write("To add more lines.")
#		#print "AAA> "+str(input)+"\n"


		hrmval=str(int(input[22]))
		spdval=str(int((input[34]*256)+input[35]))
		cadval=str(int((input[36]*256)+input[37]))
		pwrval=str(int((input[20]*256)+input[21]))


		if (int(spdval) < 10):
			spdval=0

		if (int(cadval) < 35):
			cadval=0

		filehrm.write(str(hrmval))
		filecad.write(str(cadval))
		filespd.write(str(spdval))
		filepwr.write(str(pwrval))

		filehrm.close()
		filecad.close()
		filespd.close()
		filepwr.close()

		print str(a)+" Lat "+str(dData['location']['lat'])+" Lon "+str(dData['location']['lon'])+" SPEED "+str((input[34]*256)+(input[35]))+" CAD "+str((input[36]*256)+input[37])+" POWER "+str((input[20]*256)+input[21])
		
		input = 0 
		source = 0

                #print dData

		return "null", (source, input)

        # log
        if log.isEnabledFor(logging.DEBUG):
            log.debug("received data {0}".format(input))
        
        # ensure input not short longer than header
        self._checkLength(input)
   
        headerBytes = input[:2]
        #asn comes in the next 5bytes.  
        
        asnbytes=input[2:7]
        (self._asn) = struct.unpack('<BHH',''.join([chr(c) for c in asnbytes]))
        
        #source and destination of the message
        dest = input[7:15]
        
        #source is elided!!! so it is not there.. check that.
        source = input[15:23]
        
        if log.isEnabledFor(logging.DEBUG):
            a="".join(hex(c) for c in dest)
            log.debug("destination address of the packet is {0} ".format(a))
        
        if log.isEnabledFor(logging.DEBUG):
            a="".join(hex(c) for c in source)
            log.debug("source address (just previous hop) of the packet is {0} ".format(a))
        
        # remove asn src and dest and mote id at the beginning.
        # this is a hack for latency measurements... TODO, move latency to an app listening on the corresponding port.
        # inject end_asn into the packet as well
        input = input[23:]
        
        if log.isEnabledFor(logging.DEBUG):
            log.debug("packet without source,dest and asn {0}".format(input))
        
        # when the packet goes to internet it comes with the asn at the beginning as timestamp.
         
        # cross layer trick here. capture UDP packet from udpLatency and get ASN to compute latency.
        if len(input) >37:
            if self.UINJECT_MASK == ''.join(chr(i) for i in input[-7:]):
                aux      = input[len(input)-14:len(input)-9]  # last 5 bytes of the packet are the ASN in the UDP latency packet
                diff     = self._asndiference(aux,asnbytes)   # calculate difference 
                timeinus = diff*self.MSPERSLOT                # compute time in ms
                SN       = input[len(input)-9:len(input)-7]   # SN sent by mote
                if timeinus<0xFFFF:
                    # print "source {0}, dest {1}, timeinus {2}ms, SN {3}".format(source, dest,timeinus,SN)
                    pass
                else:
                    # this usually happens when the serial port framing is not correct and more than one message is parsed at the same time. this will be solved with HDLC framing.
                    print "Wrong latency computation {0} = {1} mS".format(str(node),timeinus)
                    print ",".join(hex(c) for c in input)
                    log.warning("Wrong latency computation {0} = {1} mS".format(str(node),timeinus))
                    pass
                # in case we want to send the computed time to internet..
                # computed=struct.pack('<H', timeinus)#to be appended to the pkt
                # for x in computed:
                    #input.append(x)
            else:
                # no udplatency
                # print input
                pass     
        else:
            pass      
       
        eventType='data'
        # notify a tuple including source as one hop away nodes elide SRC address as can be inferred from MAC layer header
        return eventType, (source, input)

 #======================== private =========================================
 
    def _asndiference(self,init,end):
      
       asninit = struct.unpack('<HHB',''.join([chr(c) for c in init]))
       asnend  = struct.unpack('<HHB',''.join([chr(c) for c in end]))
       if asnend[2] != asninit[2]: #'byte4'
          return 0xFFFFFFFF
       else:
           pass
       
       diff = 0
       if asnend[1] == asninit[1]:#'bytes2and3'
          return asnend[0]-asninit[0]#'bytes0and1'
       else:
          if asnend[1]-asninit[1]==1:##'bytes2and3'              diff  = asnend[0]#'bytes0and1'
              diff += 0xffff-asninit[0]#'bytes0and1'
              diff += 1
          else:   
              diff = 0xFFFFFFFF
       
       return diff
