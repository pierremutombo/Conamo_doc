# -*- coding: utf-8 -*-
"""
This example demonstrates many of the 2D plotting capabilities
in pyqtgraph. All of the plots may be panned/scaled by dragging with
the left/right mouse buttons. Right click on any plot to show a context menu.
"""
 
 
from pyqtgraph.Qt import QtGui, QtCore
import numpy as np
import pyqtgraph as pg
 
#QtGui.QApplication.setGraphicsSystem('raster')
app = QtGui.QApplication([])
#mw = QtGui.QMainWindow()
#mw.resize(800,800)
 
pg.setConfigOption('background', 'w')
pg.setConfigOption('foreground', 'k')
ptr1 = 0
ptr2 = 0
ptr3 = 0
ptr4= 0
win = pg.GraphicsWindow(title="CONAMO (Continuous Athlete Monitoring) Cyclist Monitoring")
win.resize(1000,600)
win.setWindowTitle('pyqtgraph example: Plotting')
 
# Enable antialiasing for prettier plots
pg.setConfigOptions(antialias=True)

p1 = win.addPlot(title="Heart Rate Monitor (beats per minute)")
data1 = np.random.normal(size=1000)
curve1 = p1.plot(data1, pen=(255,0,0), name="Red curve")
p1.setYRange(1, 200, padding=0) 

win.nextRow()
 
p2 = win.addPlot(title="Power meter (wattage)")
data2 = np.random.normal(size=1000)
curve2 = p2.plot(data2, pen=(0,0,255), name="Blue curve")
p2.setYRange(1, 600, padding=0) 

win.nextRow()
 
p3 = win.addPlot(title="Cadence (rpm)")
data3 = np.random.normal(size=1000)
curve3 = p3.plot(data3, pen=(0,0,255), name="Blue curve")
p3.setYRange(1, 300, padding=0) 

win.nextRow()
 
p4 = win.addPlot(title="Speed (kph)")
data4 = np.random.normal(size=1000)
curve4 = p4.plot(data4, pen=(0,0,255), name="Blue curve")
p4.setYRange(1, 60, padding=0) 

print "hey3" 
 
def update1():
    global data1, ptr1
    data1[:-1] = data1[1:]  # shift data in the array one sample left
                            # (see also: np.roll)
    #data1[-1] = np.random.normal()
    file1 = open("filehrm","r") 
    a= float(file1.read())
    data1[-1] = abs(a)
 
    ptr1 += 1
    curve1.setData(data1)
    curve1.setPos(ptr1, 0)
 
def update2():
    global data2, ptr2

    data2[:-1] = data2[1:]  # shift data in the array one sample left
                            # (see also: np.roll)
    #data2[-1] = np.random.normal()
    file2 = open("filepwr","r") 
    b= float(file2.read())

    data2[-1] = abs(b)
 
    ptr2 += 1
    curve2.setData(data2)
    curve2.setPos(ptr2, 0)

def update3():
    global data3, ptr3

    data3[:-1] = data3[1:]  # shift data in the array one sample left
                            # (see also: np.roll)
    #data2[-1] = np.random.normal()
    file3 = open("filecad","r") 
    b= float(file3.read())

    data3[-1] = abs(b)
 
    ptr3 += 1
    curve3.setData(data3)
    curve3.setPos(ptr3, 0)

def update4():
    global data4, ptr4

    data4[:-1] = data4[1:]  # shift data in the array one sample left
                            # (see also: np.roll)
    #data2[-1] = np.random.normal()
    file4 = open("filespd","r") 
    b= float(file4.read())

    data4[-1] = abs(b)
 
    ptr4 += 1
    curve4.setData(data4)
    curve4.setPos(ptr4, 0)
 
# update all plots
def update():
    update1()
    update2()
    update3()
    update4()
 
timer = pg.QtCore.QTimer()
timer.timeout.connect(update)
timer.start(50)
print "hey" 

## Start Qt event loop unless running in interactive mode or using pyside.
if __name__ == '__main__':
    import sys
    print "hey0" 
    if (sys.flags.interactive != 1) or not hasattr(QtCore, 'PYQT_VERSION'):
        QtGui.QApplication.instance().exec_()
	print "hey2" 

