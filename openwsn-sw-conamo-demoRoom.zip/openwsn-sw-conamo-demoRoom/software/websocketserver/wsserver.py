class SingletonWS:
    # Here will be the instance stored.
    __instance = None

    @staticmethod
    def getInstance():
        """ Static access method. """
        if SingletonWS.__instance == None:
            SingletonWS()
        return SingletonWS.__instance

    def __init__(self):
        """ Virtually private constructor. """
        if SingletonWS.__instance != None:
            raise Exception("This class is a SingletonWS!")
        else:
            SingletonWS.__instance = self

    def printInstance(self):
	print 'This is the SingletonWS!'
        print __instance
