class SingletonWS:
    # Here will be the instance stored.
    __instance = None
    __v = []
    __enabled = False

    @staticmethod
    def getInstance():
        """ Static access method. """
        if SingletonWS.__instance == None:
            SingletonWS()
        return SingletonWS.__instance

    def __init__(self):
        """ Virtually private constructor. """
        if SingletonWS.__instance != None:
            raise Exception("This class is a SingletonWS!")
        else:
            SingletonWS.__instance = self

        self.clients = []

    def getClients(self):
	return self.clients

    def broadcastToClients(self, data):
        for client in self.clients:
            client.sendMessage(unicode(data))

    def enable(self):
        self.__enabled = True

    def isEnabled(self):
        return self.__enabled

    def printInstance(self):
	print 'This is the SingletonWS!'
        print SingletonWS.__instance
        __instance.__v.append(1)
        print __instance.__v
